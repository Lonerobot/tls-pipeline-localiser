import RandomTile

toolbar = nuke.menu('Nodes')
toolbar.addCommand( 'Random Tile', 'RandomTile.randomTile()','',icon='RandomTile.png')